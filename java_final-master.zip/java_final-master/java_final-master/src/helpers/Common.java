package helpers;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Common {
    /**
     * Retrieves current date and time and then formats it.
     * @return formatted date
     */
    public static String getCurrentDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

    /**
     * Instantiates a new Save Dialog. When user selects the output directory,
     * the JTable will be extracted into loanData.xls
     * @param model JTable's model
     */
    public static void exportTableToXls(DefaultTableModel model) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); // Set selection to directories only

        int option = fileChooser.showSaveDialog(null);
        if (option == JFileChooser.APPROVE_OPTION) {
            try {
                File excelFile = new File(fileChooser.getSelectedFile() + "/loanData.xls");
                FileWriter fileWriter = new FileWriter(excelFile);
                for (int i = 0; i < model.getColumnCount(); i++) {
                    fileWriter.write(model.getColumnName(i) + ",");
                }
                fileWriter.write("\n");
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = (String) model.getValueAt(i, j);
                        if (Objects.equals(data, "null")) {
                            data = "";
                        }
                        fileWriter.write(data + ",");
                    }
                    fileWriter.write("\n");
                }

                fileWriter.close();
                JOptionPane.showMessageDialog(null, "Data exported successfully!", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Couldn't export data.", "ERROR",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
