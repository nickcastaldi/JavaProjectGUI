package main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Search {

    public Search() {
        // Empty constructor. This class contains static classes only.
    }

    /**
     * Returns row (split) from the DATA_FILE.
     * @param text Line from file
     * @return line.split
     */
    public static String[] getRow(String text) {
        String line = text.replaceAll(" ", ""); // REMOVE ALL SPACES IF USER USED SPACE
        line = line.replaceAll("\"", "");
        return line.split(",");
    }

    /**
     * OR Search
     * @param table JTable
     * @param query User's search query
     * @param model JTable's model
     */
    public static void orSearch(JTable table, String query, DefaultTableModel model) {
        TableRowSorter<DefaultTableModel> TRS = new TableRowSorter<>(model);
        table.setRowSorter(TRS);

        String[] tRow = getRow(query);
        List<RowFilter<Object, Object>> orFilters = new ArrayList<>(tRow.length);
        for (String s : tRow) {
            orFilters.add(RowFilter.regexFilter(s));
        }
        RowFilter<Object, Object> orFilter = RowFilter.orFilter(orFilters);
        TRS.setRowFilter(orFilter);
    }

    /**
     * AND search
     * @param table JTable
     * @param query User's search query
     * @param model JTable's model
     */
    public static void andSearch(JTable table, String query, DefaultTableModel model) {
        TableRowSorter<DefaultTableModel> TRS = new TableRowSorter<>(model);
        table.setRowSorter(TRS);
        String[] tRow = getRow(query);
        List<RowFilter<Object, Object>> andFilters = new ArrayList<>(tRow.length);
        for (String s : tRow) {
            andFilters.add(RowFilter.regexFilter(s));
        }

        RowFilter<Object, Object> andFilter = RowFilter.andFilter(andFilters);
        TRS.setRowFilter(andFilter);
    }

    /**
     * Free search
     * @param table JTable
     * @param query User's search query
     * @param model JTable's model
     */
    public static void freeSearch(JTable table, String query, DefaultTableModel model) {
        TableRowSorter<DefaultTableModel> TRS = new TableRowSorter<>(model);
        table.setRowSorter(TRS);
        TRS.setRowFilter(RowFilter.regexFilter(query));
    }

}