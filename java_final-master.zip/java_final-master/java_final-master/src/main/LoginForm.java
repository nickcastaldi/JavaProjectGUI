package main;

import javax.swing.*;
import java.awt.*;

public class LoginForm extends javax.swing.JFrame {
    private JPanel MainPanel;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnCreate;
    private JLabel labelUsername;
    private JLabel labelPassword;
    private JPanel buttonPanel;

    public LoginForm() {
        this.setContentPane(MainPanel);
        this.setTitle("Loan Management - Login");
        this.setSize(500, 200);
        this.getContentPane().setBackground(Color.WHITE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        buttonPanel.setBackground(Color.WHITE);

        btnCreate.addActionListener(e -> new SignUpForm().setVisible(true));

        btnLogin.addActionListener(e -> {
            String user = txtUsername.getText();
            String pass = new String(txtPassword.getPassword());
            Users login = new Users(user, pass);
            if (!user.isEmpty() && !pass.isEmpty()) {
                try {
                    boolean result = login.checkCredentials(user, pass);
                    if (result) { // if  credentials are correct
                        new MainForm(login).setVisible(true);
                        this.setVisible(false);
                    } else { // if credentials are wrong
                        JOptionPane.showMessageDialog(null, "Wrong username or password.", "Wrong Credentials", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please fill all the required fields.", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
}
