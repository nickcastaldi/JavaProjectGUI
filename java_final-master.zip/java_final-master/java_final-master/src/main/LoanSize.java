package main;

public enum LoanSize {
    SMALL,
    MEDIUM,
    LARGE,
    OTHER
}
