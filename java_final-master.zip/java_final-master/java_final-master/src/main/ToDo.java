package main;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ToDo {

    private final String toDo;
    private static final String DATA_FILE = "data/";

    public ToDo(String toDo) {
        this.toDo = toDo;
    }

    /**
     * Loads the to-do items in the model.
     * @param model DefaultListModel
     * @param username User's username.
     */
    @SuppressWarnings("unchecked")
    public static void loadToDo(DefaultListModel model, String username) {
        File f = new File(DATA_FILE + username + "/todo.dat");
        try (Scanner s = new Scanner(f)) {
            while (s.hasNextLine()) {
                String line = s.nextLine();
                model.addElement(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Couldn't load your to-do list.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Saves to-do items.
     * @param model DefaultListModel
     * @param username User's username.
     * @throws IOException Possible IO Exception.
     */
    public static void saveToDo(DefaultListModel model, String username) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE + username + "/todo.dat", false));
        for (int i = 0; i < model.size(); i++) {
            writer.println(model.get(i));
        }
        writer.close();
    }

    /**
     * Adds new item to the to-do list.
     * @param item To-Do item
     * @param model DefaultListModel
     * @param username User's username.
     */
    public void addToDo(String item, DefaultListModel model, String username) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE + username + "/todo.dat", true));
            writer.println(item);
            writer.close();
            model.addElement(item);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return object as string
     */
    @Override
    public String toString() {
        return toDo;
    }

}