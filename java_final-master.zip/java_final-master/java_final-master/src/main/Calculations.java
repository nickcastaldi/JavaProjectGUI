package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Calculations {
    /**
     * Finds the most common loan type.
     * @param values ArrayList containing all required values
     * @return mostCommonValue
     */
    public String mostCommon(ArrayList<String> values) {
        Map<String, Integer> map = new HashMap<>();

        for (String value : values) {
            map.merge(value, 1, Integer::sum);
        }

        String mostCommonValue = null;
        int maxValue = -1;
        for(Map.Entry<String, Integer> entry: map.entrySet()) {

            if(entry.getValue() > maxValue) {
                mostCommonValue = entry.getKey();
                maxValue = entry.getValue();
            }
        }

        return mostCommonValue;
    }

    /**
     * Calculates the average value of all loans created by the user.
     * @param values ArrayList containing all required values
     * @return average value
     */
    public double averageValue(ArrayList<Double> values) {
        double sum = 0;
        int size = values.size();
        for (double value : values) {
            sum += value;
        }
        return (Math.round(sum * 100.0) / 100.0) / size;
    }
}
