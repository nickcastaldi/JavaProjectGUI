package main;

import javax.swing.*;
import java.util.ArrayList;

public class LoanCalculations extends Calculations {

    private final JTable loanTable;

    public LoanCalculations(JTable loanTable) {
        this.loanTable = loanTable;
    }

    /**
     * Loads all loan sizes from the JTable
     * @return loanSizes
     */
    public ArrayList<String> getLoanSizes() {
        ArrayList<String> loanSizes = new ArrayList<>();
        for (int i = 0; i < loanTable.getRowCount(); i++) {
            String loanSize = String.valueOf(loanTable.getValueAt(i, 9));
            loanSizes.add(loanSize);
        }
        return loanSizes;
    }

    /**
     * Loads all loan amounts from the JTable
     * @return loanAmounts
     */
    public ArrayList<Double> getAverageLoanSizes() {
        ArrayList<Double> loanAmounts = new ArrayList<>();
        for (int i = 0; i < loanTable.getRowCount(); i++) {
            Double loanAmount = Double.valueOf(String.valueOf(loanTable.getValueAt(i, 4)));
            loanAmounts.add(loanAmount);
        }
        return loanAmounts;
    }
}
