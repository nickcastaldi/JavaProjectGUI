package main;

import helpers.Common;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;

public class LoanManagement {

    private final String who;
    private final String name;
    private final double annualInterestRate;
    private double monthlyInterestRate;
    private final double loanAmount;
    private final int numOfYears;
    private static final String DATA_FILE = "data/";

    public LoanManagement(String who, String name, double annualInterestRate, double loanAmount, int numOfYears) {
        this.who = who;
        this.name = name;
        this.annualInterestRate = annualInterestRate;
        this.loanAmount = loanAmount;
        this.numOfYears = numOfYears;
    }

    /**
     * Calculates and returns the monthly interest rate.
     */
    public double getMonthlyInterestRate() {
        return annualInterestRate / 1200;
    }

    /**
     * Sets the monthly interest rate.
     * @param monthlyInterestRate User provided monthly interest rate.
     */
    public void setMonthlyInterestRate(double monthlyInterestRate) {
        this.monthlyInterestRate = monthlyInterestRate;
    }

    /**
     * Calculates and returns the monthly loan payment.
     */
    public double calculateMonthlyPayment() {
        return loanAmount * monthlyInterestRate / (1 - 1 / Math.pow(1 + monthlyInterestRate, numOfYears * 12));
    }

    /**
     * Calculates and returns the total payment.
     * @param monthlyPayment User provided monthly payment
     */
    public double calculateTotalPayment(double monthlyPayment) {
        return monthlyPayment * numOfYears * 12;
    }

    /**
     * Saves the loan information to the DATA_FILE.
     * @param information All information regarding the loan.
     */
    public void saveLoanInformation(String information) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE + who + "/loans.dat", true));
            writer.println(information);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Saves new loans.
     * @param activityTable This is the loanTable
     * @param toAppend Data to append
     * @param username User's username
     */
    public static void saveChanges(JTable activityTable, boolean toAppend, String username) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE  + username + "/loans.dat", toAppend));
            for (int row = 0; row < activityTable.getRowCount(); row++) {
                for (int col = 0; col < activityTable.getColumnCount(); col++) {
                    if (activityTable.getColumnCount() - col == 1) {
                        writer.write(activityTable.getValueAt(row, col).toString());
                    } else {
                        writer.write(activityTable.getValueAt(row, col).toString() + "/");
                    }
                }
                writer.write("\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads all data from the file to the JTable.
     * @param model JTable's model.
     * @param username User's username.
     */
    public static void loadData(DefaultTableModel model, String username) {
        try {
            File f = new File(DATA_FILE  + username + "/loans.dat");
            BufferedReader br = new BufferedReader(new FileReader(f));
            Object[] tableLines = br.lines().toArray();
            for (Object tableLine : tableLines) {
                String line = tableLine.toString().trim();
                String[] dataRow = line.split("/");
                model.addRow(dataRow);
            }
            br.close(); // close buffered reader
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Calculates the category of the loan based on the amount.
     * @param loanAmount Loan Amount
     * @return userLoanSize
     */
    public LoanSize calculateLoanSize(double loanAmount) {
        LoanSize userLoanSize;
        if (loanAmount < 20000) {
            userLoanSize = LoanSize.SMALL;
        } else if (loanAmount >= 20000 && loanAmount < 40000) {
            userLoanSize = LoanSize.MEDIUM;
        } else if (loanAmount >= 40000 && loanAmount <= 70000) {
            userLoanSize = LoanSize.LARGE;
        } else {
            userLoanSize = LoanSize.OTHER;
        }
        return userLoanSize;
    }

    /**
     * Create the columns for the table.
     * @param model JTable's model
     */
    public static void createColumns(DefaultTableModel model) {
        model.addColumn("Operator");
        model.addColumn("Customer");
        model.addColumn("Date & Time");
        model.addColumn("Number of years");
        model.addColumn("Loan Amount");
        model.addColumn("Annual Interest Rate");
        model.addColumn("Monthly Interest Rate");
        model.addColumn("Monthly Payment");
        model.addColumn("Total Payment");
        model.addColumn("Loan Size");
    }

    /**
     * Create the string to be saved when a new loan is created.
     * @param monthlyPayment Monthly Payment
     * @param totalPayment Total Payment
     * @param loanSize Loan Size
     */
    public String loanInformation(double monthlyPayment, double totalPayment, LoanSize loanSize) {
        return who + "/" + name + "/" + Common.getCurrentDate() + "/" + numOfYears + "/" + loanAmount +
                "/" + annualInterestRate + "/" + monthlyInterestRate + "/" + monthlyPayment + "/" + totalPayment +
                "/" + loanSize;
    }
}
