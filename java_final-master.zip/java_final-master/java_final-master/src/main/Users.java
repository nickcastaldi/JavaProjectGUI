package main;

import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Users {
    public String username;
    private final String password;
    private static final String DATA_FILE = "data/users.dat";
    private static final String USER_DIR = "data/";

    /**
     * @param username User provided username
     * @param password User provided password
     */
    public Users(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Creates new user.
     * @param userInfo All user information.
     * @param username User's username
     */
    public void newUser(String userInfo, String username) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE, true));
            writer.println(userInfo);
            writer.close();
            File newUser = new File(USER_DIR + username);
            boolean result = newUser.mkdir(); // create user folder
            if (!result) {
                throw new Exception("Couldn't create required folder!");
            }
            JOptionPane.showMessageDialog(null, "Account created successfully!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks if user exists. If user exists, then login.
     * @param username User's username
     * @param password User's password
     * @return found
     */
    public boolean checkCredentials(String username, String password) {
        try {
            File f = new File(DATA_FILE);
            boolean found = false;
            try (Scanner s = new Scanner(f)) {
                while (s.hasNextLine()) {
                    String line = s.nextLine();
                    line = line.replaceAll("\"", "");
                    String[] row = line.split(",");
                    if (row[0].equals(username) && row[1].equals(password)) {
                        found = true;
                        break;
                    }
                }
            }
            return found;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks if username exists during account creation.
     * @param username User's username
     * @return found
     */
    public boolean checkIfUsernameExists(String username) {
        try {
            boolean found = false;
            File f = new File(DATA_FILE);
            try (Scanner s = new Scanner(f)) {
                while (s.hasNextLine()) {
                    String line = s.nextLine();
                    line = line.replaceAll("\"", "");
                    String[] row = line.split(","); // store line to array
                    if (row[0].equals(username)) {
                        found = true;
                        break; // if exists, break loop
                    }
                }
            }

            return found;
        } catch (FileNotFoundException e) {
            return false;
        }
    }

    /**
     * Creates user files locally.
     * @param username User's username
     */
    public void createUserFiles(String username) {
        try {
            File loans = new File(USER_DIR + username + "/loans.dat");
            File todo = new File(USER_DIR + username + "/todo.dat");
            boolean firstResult = loans.createNewFile();
            if (!firstResult) {
                JOptionPane.showMessageDialog(null, "Couldn't create loans.dat file!", "Error", JOptionPane.ERROR_MESSAGE);
            }

            boolean secondResult = todo.createNewFile();
            if (!secondResult) {
                JOptionPane.showMessageDialog(null, "Couldn't create todo.dat file!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Something went wrong!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks if files exist or not.
     */
    public void checkIfFileExists() {
        File usersDirectory = new File("data");
        File usersFile = new File("data/users.dat");
        if (!usersDirectory.exists()) { // if folder doesn't exist. Create it.
            boolean result = usersDirectory.mkdir(); // create directory
            if (!result) {
                JOptionPane.showMessageDialog(null, "Couldn't create user directory!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                if (!usersFile.exists()) {
                    try {
                        boolean fileResult = usersFile.createNewFile(); // create file to store users
                        if (!fileResult) {
                            JOptionPane.showMessageDialog(null, "Failed to crete users.dat", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public String toString() {
        return username + "," + password;
    }
}