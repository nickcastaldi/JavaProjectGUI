package main;

import javax.swing.*;
import java.awt.*;

public class SignUpForm extends javax.swing.JFrame {
    private JPanel panelMain;
    private JTextField txtUsername;
    private JButton btnCreate;
    private JLabel labelUsername;
    private JPasswordField txtPassword;
    private JPanel ButtonPanel;

    public SignUpForm() {
        this.setTitle("Loan Management - Sign Up");
        this.setContentPane(panelMain);
        this.setSize(500, 200);
        this.getContentPane().setBackground(Color.WHITE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        btnCreate.addActionListener(e -> {
            boolean userExist = false;
            String user = txtUsername.getText(); // get username
            String pass = String.valueOf(txtPassword.getPassword()); // get password
            Users newUser = new Users(user, pass); // Create Users object
            if (!user.isEmpty() && !pass.isEmpty()) { // check if everything is filled (except e-mail)
                String userFinal = newUser.toString(); // store this in user's file
                newUser.checkIfFileExists();
                try {
                    userExist = newUser.checkIfUsernameExists(user); // check if there's a similar username
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                if (!userExist) {
                    newUser.newUser(userFinal, user);
                    newUser.createUserFiles(user);
                    setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(null, "Username already exists!", "Information",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please fill all required fields!", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
}
