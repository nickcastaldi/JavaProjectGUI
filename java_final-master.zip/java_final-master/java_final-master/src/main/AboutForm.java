package main;

import javax.swing.*;
import java.awt.*;

public class AboutForm extends javax.swing.JFrame {
    private JLabel lblTitle;
    private JLabel lblVersion;
    private JPanel aboutPanel;

    public AboutForm() {
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.getContentPane().setBackground(Color.WHITE);
        this.setTitle("About");
        this.setContentPane(aboutPanel);
        this.setResizable(false);
        this.pack();
        this.setLocationRelativeTo(null);
    }
}
