package main;

import helpers.Common;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MainForm extends javax.swing.JFrame {
    private JPanel panelMain;
    private JMenu accountMenu;
    private JMenuItem logoutMenuItem;
    private JTable loanTable;
    private JMenuItem exitMenuItem;
    private JMenu otherMenu;
    private JTextField txtInterestRate;
    private JTextField txtYears;
    private JTextField txtAmount;
    private JButton addNewLoanButton;
    private JScrollPane scrollPane;
    private JLabel labelWho;
    private JButton removeSelectedButton;
    private JTextField txtName;
    private JMenuItem toDoItem;
    private JComboBox<String> searchBox;
    private JTextField txtSearch;
    private JButton searchButton;
    private JButton exportTableButton;
    private JMenuItem mostCommonSize;
    private JMenuItem averageSize;
    private JPanel loanPanel;
    private JPanel searchPanel;
    private JLabel labelCount;
    private JToolBar statusBar;
    private JButton btnAbout;
    private JPanel panelLoanButton;
    private JButton btnReset;

    public MainForm(Users loggedUser) {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Loan Management");
        this.setContentPane(panelMain);
        this.getContentPane().setBackground(Color.WHITE);
        this.pack();
        this.setLocationRelativeTo(null);

        scrollPane.setViewportView(loanTable);
        DefaultTableModel defaultTableModel = new DefaultTableModel();
        loanTable.setModel(defaultTableModel);
        loanTable.getTableHeader().setReorderingAllowed(false); // Disable re-ordering of table headers
        LoanManagement.createColumns(defaultTableModel);
        LoanManagement.loadData(defaultTableModel, loggedUser.getUsername());
        labelCount.setText("Total loans: " + countRows());

        labelWho.setText("Welcome, " + loggedUser.getUsername());
        loanPanel.setBackground(Color.WHITE);
        scrollPane.setBackground(Color.WHITE);
        searchPanel.setBackground(Color.WHITE);
        statusBar.setBackground(Color.WHITE);
        panelLoanButton.setBackground(Color.WHITE);

        exitMenuItem.addActionListener(e -> System.exit(1));

        removeSelectedButton.addActionListener(e -> {
            if (!loanTable.getSelectionModel().isSelectionEmpty()) { // Check if user selected a row to delete
                ((DefaultTableModel) loanTable.getModel()).removeRow(loanTable.getSelectedRow());
                LoanManagement.saveChanges(loanTable, false, loggedUser.getUsername());
                labelCount.setText("Total loans: " + countRows());
            } else {
                JOptionPane.showMessageDialog(null, "Please select an item first.", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        addNewLoanButton.addActionListener(e -> {
            String annualInterest = txtInterestRate.getText();
            String numOfYears = txtYears.getText();
            String loanAmount = txtAmount.getText();
            String customerName = txtName.getText();
            if (!annualInterest.isEmpty() && !numOfYears.isEmpty() && !loanAmount.isEmpty()) {
                try {
                    double convertedAnnual = Double.parseDouble(annualInterest);
                    int convertedYears = Integer.parseInt(numOfYears);
                    double convertedAmount = Double.parseDouble(loanAmount);
                    String currentOperator = loggedUser.getUsername();

                    LoanManagement loanManagement = new LoanManagement(currentOperator, customerName, convertedAnnual, convertedAmount, convertedYears);
                    double monthlyInterestRate = loanManagement.getMonthlyInterestRate();
                    loanManagement.setMonthlyInterestRate(monthlyInterestRate);
                    double mPayment = loanManagement.calculateMonthlyPayment();
                    double tPayment = loanManagement.calculateTotalPayment(mPayment);
                    LoanSize loanSize = loanManagement.calculateLoanSize(convertedAmount);
                    defaultTableModel.addRow(new Object[] { currentOperator, customerName, Common.getCurrentDate(),
                                            numOfYears, convertedAmount, convertedAnnual,
                                            monthlyInterestRate, mPayment, tPayment, loanSize });

                    loanManagement.saveLoanInformation(loanManagement.loanInformation(mPayment, tPayment, loanSize));
                    clearText();
                    labelCount.setText("Total loans: " + countRows());
                } catch (Exception error) {
                    JOptionPane.showMessageDialog(null, "Please enter valid input in the fields.", "Information",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please fill all the required fields.", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        toDoItem.addActionListener(e -> new ToDoForm(loggedUser).setVisible(true));

        logoutMenuItem.addActionListener(e -> {
            this.setVisible(false);
            new LoginForm().setVisible(true);
        });

        txtSearch.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (searchBox.getSelectedIndex() == 0) // if free search
                    Search.freeSearch(loanTable, txtSearch.getText(), defaultTableModel);
            }
        });

        searchButton.addActionListener(e -> {
            if (searchBox.getSelectedIndex() == 1) { // if AND search
                Search.andSearch(loanTable, txtSearch.getText(), defaultTableModel);
            } else if (searchBox.getSelectedIndex() == 2) { // if OR search
                Search.orSearch(loanTable, txtSearch.getText(), defaultTableModel);
            }
        });

        exportTableButton.addActionListener(e -> Common.exportTableToXls(defaultTableModel));

        mostCommonSize.addActionListener(actionEvent -> {
            LoanCalculations loanCalculations = new LoanCalculations(loanTable);
            ArrayList<String> loanSizes = loanCalculations.getLoanSizes();
            String result = loanCalculations.mostCommon(loanSizes);
            JOptionPane.showMessageDialog(null, "The most common loan size is: " + result, "Result",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        averageSize.addActionListener(actionEvent -> {
            LoanCalculations loanCalculations = new LoanCalculations(loanTable);
            ArrayList<Double> loanAmounts = loanCalculations.getAverageLoanSizes();
            double result = loanCalculations.averageValue(loanAmounts);
            JOptionPane.showMessageDialog(null, "The average loan amount is: " + result, "Result",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        btnAbout.addActionListener(actionEvent -> new AboutForm().setVisible(true));
        btnReset.addActionListener(actionEvent -> clearText());
    }

    /**
     * After a new loan is added successfully,
     * clear the text fields.
     */
    private void clearText() {
        txtAmount.setText("");
        txtInterestRate.setText("");
        txtName.setText("");
        txtYears.setText("");
    }

    private String countRows() {
        return String.valueOf(loanTable.getRowCount());
    }
}
