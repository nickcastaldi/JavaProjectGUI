package main;

import javax.swing.*;
import java.awt.*;

public class ToDoForm extends javax.swing.JFrame {
    private JList<String> toDoList;
    private JButton btnAddToDo;
    private JButton btnRemoveAll;
    private JButton removeSelectedButton;
    private JPanel panelMain;
    private JTextField txtToDo;
    private JLabel labelUsername;
    DefaultListModel defaultListModel = new DefaultListModel();

    public ToDoForm(Users loggedUser) {
        this.setTitle("Loan Management - TODO");
        this.setContentPane(panelMain);
        this.getContentPane().setBackground(Color.WHITE);
        this.pack();
        this.setResizable(false);
        this.setLocationRelativeTo(null);

        labelUsername.setText("To-Do list of user: " + loggedUser.getUsername());

        toDoList.setModel(defaultListModel);
        ToDo.loadToDo(defaultListModel, loggedUser.getUsername());

        removeSelectedButton.addActionListener(e -> {
            if (toDoList.getSelectedValue() != null) {
                defaultListModel.remove(toDoList.getSelectedIndex());
                try {
                    ToDo.saveToDo(defaultListModel, loggedUser.getUsername());
                } catch (Exception error) {
                    error.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select an item to delete!", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        btnRemoveAll.addActionListener(e -> {
            defaultListModel.removeAllElements();
            try {
                ToDo.saveToDo(defaultListModel, loggedUser.getUsername());
            } catch (Exception error) {
                error.printStackTrace();
            }
        });

        btnAddToDo.addActionListener(e -> {
            if (!txtToDo.getText().isEmpty()) {
                ToDo todo = new ToDo(txtToDo.getText());
                todo.addToDo(todo.toString(), defaultListModel, loggedUser.getUsername());
            } else {
                JOptionPane.showMessageDialog(null, "To-do item can't be empty!", "Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
}
