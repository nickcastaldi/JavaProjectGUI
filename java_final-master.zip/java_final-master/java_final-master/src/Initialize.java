import main.LoginForm;
import main.MainForm;

public class Initialize {
    public static void main(String[] args) {
        new LoginForm().setVisible(true);
    }
}
